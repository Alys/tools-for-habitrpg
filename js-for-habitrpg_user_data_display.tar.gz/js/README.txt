put this js directory at the same level as habitrpg_user_data_display.html
